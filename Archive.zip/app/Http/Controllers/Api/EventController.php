<?php

namespace App\Http\Controllers\Api;

use App\Models\{Event, EventCategory, EventBooking, Wallet, Transaction};
use App\Notifications\TicketPurchaseNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Traits\ApiResponseTrait;
use App\Constants\ResponseCode;

class EventController extends Controller
{
    use ApiResponseTrait;



public function index(Request $request)
{
    try {
        $filter = $request->query('filter');
        $clientDate = $request->query('event_date', now()->toDateString());

        $query = Event::with('category');

        if ($filter === 'upcoming' && $clientDate) {
            $query->whereDate('date', '>', $clientDate);
        } elseif ($filter === 'past' && $clientDate) {
            $query->whereDate('date', '<', $clientDate);
        }

        if (auth()->user()->role === 'user') {
            $query->whereIn('status', ['active', 'completed']);
        }

        $events = $query->orderBy('date', 'asc')->get();

        // isBooked add (structure same)
        if (auth()->check()) {
            $bookedEventIds = EventBooking::where('user_id', auth()->id())
                ->pluck('event_id')
                ->toArray();

            $events->transform(function ($event) use ($bookedEventIds) {
                $event->isBooked = in_array($event->id, $bookedEventIds);
                return $event;
            });
        }

        return $this->successResponse('SUCCESS', $events);

    } catch (\Exception $e) {
        return $this->errorResponse(
            ResponseCode::INTERNAL_SERVER_ERROR,
            'SERVER_ERROR'
        );
    }
}


    /**
     * Show event details
     */
    public function show($id)
{
    try {
        $event = Event::with('category')->find($id);

        if (!$event) {
            return $this->errorResponse(ResponseCode::NOT_FOUND, 'USER_NOT_FOUND');
        }

        // isBooked flag add
        $event->isBooked = false;

        if (auth()->check()) {
            $event->isBooked = EventBooking::where('user_id', auth()->id())
                ->where('event_id', $event->id)
                ->exists();
        }

        return $this->successResponse('SUCCESS', $event);

    } catch (\Exception $e) {
        return $this->errorResponse(
            ResponseCode::INTERNAL_SERVER_ERROR,
            'SERVER_ERROR'
        );
    }
}

    /**
     * Create a new event
     */
    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'title' => 'required|string',
                'description' => 'nullable|string',
                'date' => 'required|date',
                'time' => 'required',
                'total_seats' => 'required|integer',
                'available_seats' => 'required|integer',
                'coins' => 'required|integer',
                'category_id' => 'required|exists:event_categories,id',
                'is_online' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse(ResponseCode::VALIDATION_ERROR, 'FAILED', $validator->errors());
            }

            $event = Event::create($validator->validated());

            return $this->apiResponse(ResponseCode::CREATED, 'SUCCESS', $event);

        } catch (\Exception $e) {
            return $this->errorResponse(ResponseCode::INTERNAL_SERVER_ERROR, 'SERVER_ERROR');
        }
    }

    /**
     * Update event details
     */
    public function update(Request $request, $id)
    {
        try {
            $event = Event::find($id);
            if (!$event) {
                return $this->errorResponse(ResponseCode::NOT_FOUND, 'USER_NOT_FOUND');
            }

            $validator = Validator::make($request->all(), [
                'title' => 'sometimes|string',
                'description' => 'nullable|string',
                'date' => 'sometimes|date',
                'time' => 'sometimes',
                'total_seats' => 'sometimes|integer',
                'available_seats' => 'sometimes|integer',
                'coins' => 'sometimes|integer',
                'category_id' => 'sometimes|exists:event_categories,id',
                'is_online' => 'sometimes|boolean',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse(ResponseCode::VALIDATION_ERROR, 'FAILED', $validator->errors());
            }

            $event->update($validator->validated());

            return $this->successResponse('SUCCESS', $event);

        } catch (\Exception $e) {
            return $this->errorResponse(ResponseCode::INTERNAL_SERVER_ERROR, 'SERVER_ERROR');
        }
    }

    /**
     * Change event status
     */
    public function changeStatus(Request $request, $id)
    {
        try {
            $event = Event::find($id);
            if (!$event) {
                return $this->errorResponse(ResponseCode::NOT_FOUND, 'USER_NOT_FOUND');
            }

            $validator = Validator::make($request->all(), [
                'status' => 'required|in:active,inactive,completed',
            ]);

            if ($validator->fails()) {
                return $this->errorResponse(ResponseCode::VALIDATION_ERROR, 'FAILED', $validator->errors());
            }

            $event->status = $request->status;
            $event->save();

            return $this->successResponse('SUCCESS', $event);

        } catch (\Exception $e) {
            return $this->errorResponse(ResponseCode::INTERNAL_SERVER_ERROR, 'SERVER_ERROR');
        }
    }

    /**
     * Book an event
     */
    public function book($id)
    {
        try {
            $event = Event::find($id);
            $user = Auth::user();

            if (!$event) {
                return $this->errorResponse(ResponseCode::NOT_FOUND, 'USER_NOT_FOUND');
            }

             $alreadyBooked = EventBooking::where('user_id', $user->id)
            ->where('event_id', $event->id)
            ->exists();

        if ($alreadyBooked) {
            return $this->errorResponse(
                ResponseCode::BAD_REQUEST,
                'You have already booked this event',
                ['message' => 'You have already booked this event']
            );
        }

            if ($event->available_seats <= 0) {
                return $this->errorResponse(ResponseCode::BAD_REQUEST, 'No seats available', ['message' => 'No seats available']);
            }

          $wallet = Wallet::firstOrCreate(
    ['user_id' => $user->id],       // search only by user
    ['balance' => 999999]            // default if not found
);


            if ($wallet->balance < $event->coins) {
                return $this->errorResponse(ResponseCode::BAD_REQUEST, 'Insufficient coins', ['message' => 'Insufficient coins']);
            }

            EventBooking::create([
                'user_id' => $user->id,
                'event_id' => $event->id,
            ]);

            $event->decrement('available_seats');
            $wallet->decrement('balance', $event->coins);

            Transaction::create([
                'user_id' => $user->id,
                'type' => 'debit',
                'amount' => $event->coins,
                'description' => 'Event booking: ' . $event->title,
            ]);

            $user->notify(new TicketPurchaseNotification($event->title, $event->date, $event->time));

            return $this->successResponse('Event booked successfully', ['message' => 'Event booked successfully']);

        } catch (\Exception $e) {
            return $this->errorResponse(ResponseCode::INTERNAL_SERVER_ERROR, 'SERVER_ERROR');
        }
    }
}

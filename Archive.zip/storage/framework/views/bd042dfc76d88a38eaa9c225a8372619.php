<?php $__env->startSection('title', 'Add Event'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <a href="<?php echo e(route('admin.events.index')); ?>" class="text-[var(--meta-text-secondary)] hover:text-white text-sm transition">← Events</a>
    <h1 class="admin-page-title mt-1">Add Event</h1>
</div>

<div class="admin-card p-6 max-w-2xl">
    <form method="POST" action="<?php echo e(route('admin.events.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="space-y-4">
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Title *</label>
                <input type="text" name="title" value="<?php echo e(old('title')); ?>" required class="admin-input">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Category *</label>
                <select name="category_id" required class="admin-input">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Description</label>
                <textarea name="description" rows="3" class="admin-input"><?php echo e(old('description')); ?></textarea>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Date *</label>
                    <input type="date" name="date" value="<?php echo e(old('date')); ?>" required class="admin-input">
                </div>
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Time *</label>
                    <input type="text" name="time" value="<?php echo e(old('time')); ?>" placeholder="e.g. 18:00" required class="admin-input">
                </div>
            </div>
            <div class="grid grid-cols-3 gap-4">
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Total seats *</label>
                    <input type="number" name="total_seats" value="<?php echo e(old('total_seats', 100)); ?>" min="1" required class="admin-input">
                </div>
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Available seats *</label>
                    <input type="number" name="available_seats" value="<?php echo e(old('available_seats', 100)); ?>" min="0" required class="admin-input">
                </div>
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Coins (price) *</label>
                    <input type="number" name="coins" value="<?php echo e(old('coins', 0)); ?>" min="0" required class="admin-input">
                </div>
            </div>
            <div class="flex items-center gap-4">
                <input type="hidden" name="is_online" value="0">
                <label class="flex items-center gap-2 text-meta-secondary">
                    <input type="checkbox" name="is_online" value="1" <?php echo e(old('is_online') ? 'checked' : ''); ?> class="rounded border-white/20 bg-white/5 text-[#6A5CFF]">
                    Online event
                </label>
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Status</label>
                    <select name="status" class="admin-input w-auto">
                        <option value="active" <?php echo e(old('status', 'active') === 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Cover image URL</label>
                <input type="text" name="cover_image" value="<?php echo e(old('cover_image')); ?>" placeholder="https://..." class="admin-input">
            </div>
        </div>
        <div class="mt-6 flex gap-3">
            <button type="submit" class="admin-btn-primary">Create Event</button>
            <a href="<?php echo e(route('admin.events.index')); ?>" class="admin-btn-ghost">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/events/create.blade.php ENDPATH**/ ?>
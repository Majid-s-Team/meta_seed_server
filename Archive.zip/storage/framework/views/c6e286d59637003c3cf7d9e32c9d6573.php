<?php $__env->startSection('title', 'Edit Event'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <a href="<?php echo e(route('admin.events.index')); ?>" class="text-[var(--meta-text-secondary)] hover:text-white text-sm transition">← Events</a>
    <h1 class="admin-page-title mt-1">Edit Event</h1>
</div>
<?php if($errors->any()): ?>
<div class="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
    <ul class="list-disc list-inside"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
</div>
<?php endif; ?>
<div class="admin-card p-6 max-w-2xl">
    <form method="POST" action="<?php echo e(route('admin.events.update', $event)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="space-y-4">
            <div>
                <label class="block text-meta-secondary text-sm mb-1">Title *</label>
                <input type="text" name="title" value="<?php echo e(old('title', $event->title)); ?>" required class="admin-input">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-meta-secondary text-sm mb-1">Category *</label>
                <select name="category_id" required class="admin-input">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id', $event->category_id) == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-meta-secondary text-sm mb-1">Description</label>
                <textarea name="description" rows="3" class="admin-input"><?php echo e(old('description', $event->description)); ?></textarea>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-meta-secondary text-sm mb-1">Date *</label>
                    <input type="date" name="date" value="<?php echo e(old('date', $event->date)); ?>" required class="admin-input">
                </div>
                <div>
                    <label class="block text-meta-secondary text-sm mb-1">Time *</label>
                    <input type="text" name="time" value="<?php echo e(old('time', $event->time)); ?>" required class="admin-input">
                </div>
            </div>
            <div class="grid grid-cols-3 gap-4">
                <div>
                    <label class="block text-meta-secondary text-sm mb-1">Total seats *</label>
                    <input type="number" name="total_seats" value="<?php echo e(old('total_seats', $event->total_seats)); ?>" min="1" required class="admin-input">
                </div>
                <div>
                    <label class="block text-meta-secondary text-sm mb-1">Available seats *</label>
                    <input type="number" name="available_seats" value="<?php echo e(old('available_seats', $event->available_seats)); ?>" min="0" required class="admin-input">
                </div>
                <div>
                    <label class="block text-meta-secondary text-sm mb-1">Coins *</label>
                    <input type="number" name="coins" value="<?php echo e(old('coins', $event->coins)); ?>" min="0" required class="admin-input">
                </div>
            </div>
            <div class="flex items-center gap-4">
                <label class="flex items-center gap-2 text-meta-secondary">
                    <input type="hidden" name="is_online" value="0">
                    <input type="checkbox" name="is_online" value="1" <?php echo e(old('is_online', $event->is_online) ? 'checked' : ''); ?> class="rounded border-white/20 bg-white/5 text-[#6A5CFF]">
                    Online event
                </label>
                <div>
                    <label class="block text-meta-secondary text-sm mb-1">Status</label>
                    <select name="status" class="admin-input w-auto">
                        <option value="active" <?php echo e(old('status', $event->status) === 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(old('status', $event->status) === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        <option value="completed" <?php echo e(old('status', $event->status) === 'completed' ? 'selected' : ''); ?>>Completed</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-meta-secondary text-sm mb-1">Cover image URL</label>
                <input type="text" name="cover_image" value="<?php echo e(old('cover_image', $event->cover_image)); ?>" class="admin-input">
            </div>
        </div>
        <div class="mt-6 flex gap-3">
            <button type="submit" class="admin-btn-primary">Update Event</button>
            <a href="<?php echo e(route('admin.events.index')); ?>" class="admin-btn-ghost">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/events/edit.blade.php ENDPATH**/ ?>
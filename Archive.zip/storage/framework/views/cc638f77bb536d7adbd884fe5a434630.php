<?php $__env->startSection('title', 'Livestreams'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6 animate-fade-in">
    <div>
        <h1 class="admin-page-title">Livestreams</h1>
        <p class="admin-page-desc">Schedule and control live streams</p>
    </div>
    <a href="<?php echo e(route('admin.livestreams.create')); ?>" class="admin-btn-primary">
        <i data-lucide="radio"></i>
        Schedule Stream
    </a>
</div>

<?php if(session('success')): ?>
    <div class="mb-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('warning')): ?>
    <div class="mb-4 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-sm"><?php echo e(session('warning')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="mb-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<form method="GET" class="flex gap-2 mb-5">
    <select name="status" class="admin-input w-auto min-w-[140px]">
        <option value="">All statuses</option>
        <option value="scheduled" <?php echo e(request('status') === 'scheduled' ? 'selected' : ''); ?>>Scheduled</option>
        <option value="live" <?php echo e(request('status') === 'live' ? 'selected' : ''); ?>>Live</option>
        <option value="ended" <?php echo e(request('status') === 'ended' ? 'selected' : ''); ?>>Ended</option>
    </select>
    <button type="submit" class="admin-btn-ghost">Filter</button>
</form>

<div class="admin-card overflow-hidden">
    <table class="admin-table w-full">
        <thead>
            <tr>
                <th>Title</th>
                <th>Scheduled</th>
                <th>Channel</th>
                <th>Price</th>
                <th>Max</th>
                <th>Viewers</th>
                <th>Health</th>
                <th>Revenue</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $livestreams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="font-medium text-white"><?php echo e($ls->title); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($ls->scheduled_at?->format('M d, H:i')); ?></td>
                    <td class="text-[var(--meta-text-muted)] font-mono text-xs"><?php echo e($ls->agora_channel); ?></td>
                    <td><?php echo e($ls->price); ?></td>
                    <td><?php echo e($ls->max_participants); ?></td>
                    <td><?php echo e($ls->current_viewer_count ?? 0); ?></td>
                    <td>
                        <?php $health = $ls->stream_health_status ?? $ls->stream_health; ?>
                        <?php if($health === 'waiting_for_broadcaster'): ?>
                            <span class="text-amber-400 text-xs">Waiting</span>
                        <?php elseif($health === 'live_receiving_feed' || $ls->stream_health === 'ok'): ?>
                            <span class="text-emerald-400 text-xs">Live</span>
                        <?php elseif($health === 'stream_offline' || $ls->stream_health === 'offline'): ?>
                            <span class="text-slate-400 text-xs">Offline</span>
                        <?php elseif($ls->stream_health === 'degraded'): ?>
                            <span class="text-amber-400 text-xs">Degraded</span>
                        <?php else: ?>
                            <span class="text-[var(--meta-text-muted)] text-xs">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-emerald-400 text-xs"><?php echo e($ls->revenue_earned ? number_format((float)$ls->revenue_earned, 2) . ' coins' : '—'); ?></td>
                    <td>
                        <?php if($ls->status === 'live'): ?>
                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-[var(--meta-live)]/20 text-[var(--meta-live)]"><span class="w-1.5 h-1.5 rounded-full bg-[var(--meta-live)] animate-pulse"></span> Live</span>
                        <?php elseif($ls->status === 'scheduled'): ?>
                            <span class="px-2.5 py-1 rounded-lg text-xs font-medium bg-blue-500/20 text-blue-400">Scheduled</span>
                        <?php else: ?>
                            <span class="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-500/20 text-slate-400">Ended</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="flex flex-wrap gap-2 items-center">
                            <a href="<?php echo e(route('admin.livestreams.broadcast', $ls)); ?>" class="text-[var(--meta-accent-end)] hover:underline text-sm font-medium">Broadcast</a>
                            <?php if(($ls->rtmp_url || $ls->rtmp_stream_key) && $ls->status === 'live'): ?>
                                <span class="text-[var(--meta-text-muted)] text-xs" title="RTMP ready">OBS</span>
                            <?php endif; ?>
                            <?php if($ls->status === 'scheduled'): ?>
                                <form action="<?php echo e(route('admin.livestreams.go-live', $ls)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--meta-live)]/20 text-[var(--meta-live)] hover:bg-[var(--meta-live)]/30 transition">Go Live</button>
                                </form>
                                <a href="<?php echo e(route('admin.livestreams.edit', $ls)); ?>" class="text-[var(--meta-accent-end)] hover:underline text-sm font-medium">Edit</a>
                            <?php endif; ?>
                            <?php if($ls->status === 'live'): ?>
                                <form action="<?php echo e(route('admin.livestreams.end-stream', $ls)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="px-3 py-1.5 rounded-lg text-xs font-medium bg-red-500/20 text-red-400 hover:bg-red-500/30 transition">End Stream</button>
                                </form>
                            <?php endif; ?>
                            <?php if(in_array($ls->status, ['scheduled', 'ended'])): ?>
                                <form action="<?php echo e(route('admin.livestreams.destroy', $ls)); ?>" method="POST" class="inline" onsubmit="return confirm('Delete this livestream?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-400 hover:underline text-sm">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10">
                        <?php echo $__env->make('admin.partials.empty', ['icon' => 'radio', 'title' => 'No livestreams yet', 'description' => 'Schedule a stream to start broadcasting.'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if($livestreams->hasPages()): ?>
        <div class="px-5 py-4 border-t border-[var(--meta-border)]"><?php echo e($livestreams->links('admin.partials.pagination')); ?></div>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/livestreams/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Edit ' . ucfirst($page->type)); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <a href="<?php echo e(route('admin.cms.index')); ?>" class="text-[var(--meta-text-secondary)] hover:text-white text-sm transition">← CMS</a>
    <a href="<?php echo e(route('admin.cms.preview', $page->type)); ?>" target="_blank" class="ml-3 text-[var(--meta-accent-end)] hover:underline text-sm">Preview</a>
    <h1 class="admin-page-title mt-1">Edit <?php echo e(ucfirst($page->type)); ?></h1>
</div>

<div class="admin-card p-6 max-w-4xl">
    <form method="POST" action="<?php echo e(route('admin.cms.update', $page->type)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="space-y-5">
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Title *</label>
                <input type="text" name="title" value="<?php echo e(old('title', $page->title)); ?>" required class="admin-input">
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Content *</label>
                <textarea name="content" rows="16" class="admin-input font-mono text-sm resize-y"><?php echo e(old('content', $page->content)); ?></textarea>
                <p class="text-[var(--meta-text-muted)] text-xs mt-2">HTML is allowed. Scripts and iframes are stripped for security.</p>
            </div>
        </div>
        <div class="mt-6 flex gap-3">
            <button type="submit" class="admin-btn-primary">
                <i data-lucide="save"></i>
                Save
            </button>
            <a href="<?php echo e(route('admin.cms.index')); ?>" class="admin-btn-ghost">Cancel</a>
        </div>
    </form>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/cms/edit.blade.php ENDPATH**/ ?>
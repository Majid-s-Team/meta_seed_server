<?php $__env->startSection('title', 'Livestream Bookings'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <a href="<?php echo e(route('admin.bookings.index')); ?>" class="text-[var(--meta-text-secondary)] hover:text-white text-sm transition">← Bookings</a>
    <h1 class="admin-page-title mt-1">Livestream Bookings</h1>
</div>

<form method="GET" class="flex flex-wrap gap-2 mb-5">
    <select name="livestream_id" class="admin-input w-auto min-w-[220px]">
        <option value="">All livestreams</option>
        <?php $__currentLoopData = $livestreams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($ls->id); ?>" <?php echo e(request('livestream_id') == $ls->id ? 'selected' : ''); ?>><?php echo e($ls->title); ?> (<?php echo e($ls->scheduled_at?->format('M d, H:i')); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="admin-btn-ghost">Filter</button>
</form>

<div class="admin-card overflow-hidden">
    <table class="admin-table w-full">
        <thead>
            <tr>
                <th>User</th>
                <th>Livestream</th>
                <th>Scheduled</th>
                <th>Booked at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="font-medium text-white"><?php echo e($b->user->name ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($b->livestream->title ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($b->livestream->scheduled_at?->format('M d, H:i') ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($b->created_at?->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">
                        <?php echo $__env->make('admin.partials.empty', ['icon' => 'radio', 'title' => 'No livestream bookings', 'description' => 'Viewer bookings will appear here.'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if($bookings->hasPages()): ?>
        <div class="px-5 py-4 border-t border-[var(--meta-border)]"><?php echo e($bookings->links('admin.partials.pagination')); ?></div>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/bookings/livestream.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Event Bookings'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-between items-center animate-fade-in">
    <div>
        <a href="<?php echo e(route('admin.bookings.index')); ?>" class="text-[var(--meta-text-secondary)] hover:text-white text-sm transition">← Bookings</a>
        <h1 class="admin-page-title mt-1">Event Bookings</h1>
    </div>
    <a href="<?php echo e(route('admin.bookings.event.export', request()->only(['event_id','date']))); ?>" class="admin-btn-ghost inline-flex items-center gap-2">
        <i data-lucide="download" class="w-4 h-4"></i>
        Export CSV
    </a>
</div>

<form method="GET" class="flex flex-wrap gap-2 mb-5">
    <select name="event_id" class="admin-input w-auto min-w-[200px]">
        <option value="">All events</option>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($e->id); ?>" <?php echo e(request('event_id') == $e->id ? 'selected' : ''); ?>><?php echo e($e->title); ?> (<?php echo e($e->date); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="admin-input w-auto">
    <button type="submit" class="admin-btn-ghost">Filter</button>
</form>

<?php if(isset($filteredRevenue)): ?>
<div class="mb-5 admin-card p-5">
    <p class="text-[var(--meta-text-secondary)] text-sm font-medium">Revenue for this event</p>
    <p class="text-2xl font-bold text-white mt-1"><?php echo e(number_format($filteredRevenue['revenue'])); ?> coins</p>
    <p class="text-[var(--meta-text-muted)] text-xs mt-1"><?php echo e($filteredRevenue['tickets']); ?> tickets sold</p>
</div>
<?php endif; ?>

<div class="admin-card overflow-hidden">
    <table class="admin-table w-full">
        <thead>
            <tr>
                <th>User</th>
                <th>Event</th>
                <th>Date</th>
                <th>Booked at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="font-medium text-white"><?php echo e($b->user->name ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($b->event->title ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($b->event->date ?? '-'); ?> <?php echo e($b->event->time ?? ''); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($b->created_at?->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">
                        <?php echo $__env->make('admin.partials.empty', ['icon' => 'clipboard-list', 'title' => 'No event bookings', 'description' => 'Bookings will appear here when users purchase tickets.'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if($bookings->hasPages()): ?>
        <div class="px-5 py-4 border-t border-[var(--meta-border)]"><?php echo e($bookings->links('admin.partials.pagination')); ?></div>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/bookings/event.blade.php ENDPATH**/ ?>
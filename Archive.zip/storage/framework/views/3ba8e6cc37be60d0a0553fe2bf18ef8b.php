<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <h1 class="admin-page-title">Users</h1>
    <p class="admin-page-desc">Manage users and access</p>
</div>

<?php if(session('success')): ?>
    <div class="mb-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="mb-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<form method="GET" class="flex flex-wrap gap-2 mb-5">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Name or email..." class="admin-input w-64">
    <select name="role" class="admin-input w-auto min-w-[120px]">
        <option value="">All roles</option>
        <option value="user" <?php echo e(request('role') === 'user' ? 'selected' : ''); ?>>User</option>
        <option value="admin" <?php echo e(request('role') === 'admin' ? 'selected' : ''); ?>>Admin</option>
    </select>
    <button type="submit" class="admin-btn-ghost">Search</button>
</form>

<div class="admin-card overflow-hidden">
    <table class="admin-table w-full">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Balance</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-[var(--meta-text-muted)]"><?php echo e($u->id); ?></td>
                    <td class="font-medium text-white"><?php echo e($u->name); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($u->email); ?></td>
                    <td>
                        <span class="inline-flex px-2.5 py-1 rounded-lg text-xs font-medium <?php echo e($u->role === 'admin' ? 'bg-[var(--meta-accent-start)]/20 text-[var(--meta-accent-end)]' : 'bg-white/10 text-[var(--meta-text-secondary)]'); ?>"><?php echo e($u->role); ?></span>
                    </td>
                    <td><?php echo e($u->wallet->balance ?? 0); ?></td>
                    <td>
                        <span class="inline-flex px-2.5 py-1 rounded-lg text-xs font-medium <?php echo e($u->is_active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'); ?>"><?php echo e($u->is_active ? 'Active' : 'Inactive'); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.users.show', $u)); ?>" class="text-[var(--meta-accent-end)] hover:underline font-medium text-sm">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        <?php echo $__env->make('admin.partials.empty', ['icon' => 'users', 'title' => 'No users found', 'description' => 'Try adjusting your search or filters.'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if($users->hasPages()): ?>
        <div class="px-5 py-4 border-t border-[var(--meta-border)]"><?php echo e($users->links('admin.partials.pagination')); ?></div>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/users/index.blade.php ENDPATH**/ ?>
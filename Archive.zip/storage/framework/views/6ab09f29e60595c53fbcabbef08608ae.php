<?php $__env->startSection('title', 'Schedule Livestream'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <a href="<?php echo e(route('admin.livestreams.index')); ?>" class="text-[var(--meta-text-secondary)] hover:text-white text-sm transition">← Livestreams</a>
    <h1 class="admin-page-title mt-1">Schedule Livestream</h1>
</div>

<div class="admin-card p-6 max-w-2xl">
    <form method="POST" action="<?php echo e(route('admin.livestreams.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="space-y-4">
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Title *</label>
                <input type="text" name="title" value="<?php echo e(old('title')); ?>" required class="admin-input">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Description</label>
                <textarea name="description" rows="3" class="admin-input"><?php echo e(old('description')); ?></textarea>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Thumbnail URL</label>
                <input type="text" name="thumbnail" value="<?php echo e(old('thumbnail')); ?>" placeholder="https://..." class="admin-input">
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Scheduled at *</label>
                <input type="datetime-local" name="scheduled_at" value="<?php echo e(old('scheduled_at')); ?>" required class="admin-input">
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Agora channel name *</label>
                <input type="text" name="agora_channel" value="<?php echo e(old('agora_channel')); ?>" required class="admin-input font-mono">
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Broadcast type</label>
                <select name="broadcast_type" class="admin-input w-full">
                    <option value="agora_rtc" <?php echo e(old('broadcast_type', 'agora_rtc') === 'agora_rtc' ? 'selected' : ''); ?>>Agora RTC (camera/app)</option>
                    <option value="rtmp" <?php echo e(old('broadcast_type') === 'rtmp' ? 'selected' : ''); ?>>RTMP (OBS/external encoder)</option>
                </select>
                <p class="text-[var(--meta-text-muted)] text-xs mt-1">RTMP: URL and stream key are auto-generated from channel (rtmp://push.agora.io/live/{channel}).</p>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">RTMP URL (for OBS)</label>
                <input type="text" name="rtmp_url" value="<?php echo e(old('rtmp_url')); ?>" placeholder="Leave empty to auto-generate for RTMP" class="admin-input font-mono text-sm">
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">RTMP stream key (for OBS)</label>
                <input type="text" name="rtmp_stream_key" value="<?php echo e(old('rtmp_stream_key')); ?>" placeholder="Leave empty to use channel name" class="admin-input font-mono text-sm">
            </div>
            <div class="flex items-center gap-2">
                <input type="hidden" name="overlay_enabled" value="0">
                <input type="checkbox" name="overlay_enabled" value="1" <?php echo e(old('overlay_enabled') ? 'checked' : ''); ?> class="rounded border-[var(--meta-border)]">
                <label class="text-[var(--meta-text-secondary)] text-sm">Enable overlay (browser source)</label>
            </div>
            <div>
                <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Scoreboard / overlay URL</label>
                <input type="text" name="scoreboard_overlay_url" value="<?php echo e(old('scoreboard_overlay_url')); ?>" placeholder="https://..." class="admin-input text-sm">
            </div>
            <div class="flex items-center gap-2">
                <input type="hidden" name="recording_enabled" value="0">
                <input type="checkbox" name="recording_enabled" value="1" <?php echo e(old('recording_enabled') ? 'checked' : ''); ?> class="rounded border-[var(--meta-border)]">
                <label class="text-[var(--meta-text-secondary)] text-sm">Recording enabled (structure only; engine TBD)</label>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Price (coins) *</label>
                    <input type="number" name="price" value="<?php echo e(old('price', 0)); ?>" min="0" step="0.01" required class="admin-input">
                </div>
                <div>
                    <label class="block text-[var(--meta-text-secondary)] text-sm font-medium mb-2">Max participants *</label>
                    <input type="number" name="max_participants" value="<?php echo e(old('max_participants', 100)); ?>" min="1" required class="admin-input">
                </div>
            </div>
        </div>
        <div class="mt-6 flex gap-3">
            <button type="submit" class="admin-btn-primary">Schedule</button>
            <a href="<?php echo e(route('admin.livestreams.index')); ?>" class="admin-btn-ghost">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/livestreams/create.blade.php ENDPATH**/ ?>
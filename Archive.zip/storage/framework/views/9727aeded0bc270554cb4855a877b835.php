<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <a href="<?php echo e(route('admin.users.index')); ?>" class="text-meta-secondary hover:text-white text-sm">← Users</a>
    <div class="flex justify-between items-start mt-2">
        <div>
            <h1 class="text-2xl font-bold text-white"><?php echo e($user->name); ?></h1>
            <p class="text-meta-secondary"><?php echo e($user->email); ?></p>
            <span class="inline-block mt-2 px-2 py-0.5 rounded text-xs <?php echo e($user->is_active ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'); ?>"><?php echo e($user->is_active ? 'Active' : 'Inactive'); ?></span>
        </div>
        <?php if($user->id !== auth()->id()): ?>
            <form action="<?php echo e(route('admin.users.toggle', $user)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <button type="submit" class="px-4 py-2 rounded-full <?php echo e($user->is_active ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'); ?> text-sm font-medium">
                    <?php echo e($user->is_active ? 'Deactivate' : 'Activate'); ?>

                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="mb-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400 text-sm"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="bg-meta-card rounded-[14px] p-6 border border-white/5">
        <h2 class="text-lg font-semibold text-white mb-4">Wallet</h2>
        <p class="text-2xl font-bold text-white"><?php echo e($user->wallet->balance ?? 0); ?> <span class="text-meta-secondary text-base font-normal">coins</span></p>
    </div>
    <div class="bg-meta-card rounded-[14px] p-6 border border-white/5">
        <h2 class="text-lg font-semibold text-white mb-4">Bookings</h2>
        <p class="text-meta-secondary text-sm">Event: <?php echo e($eventBookings->count()); ?> · Livestream: <?php echo e($user->livestreamBookings->count()); ?></p>
    </div>
</div>

<div class="mt-6 bg-meta-card rounded-[14px] border border-white/5 overflow-hidden">
    <h2 class="px-4 py-3 text-lg font-semibold text-white border-b border-white/5">Recent Transactions</h2>
    <table class="w-full">
        <thead class="bg-white/5 text-left text-meta-secondary text-sm">
            <tr>
                <th class="px-4 py-3">Type</th>
                <th class="px-4 py-3">Amount</th>
                <th class="px-4 py-3">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t border-white/5">
                    <td class="px-4 py-3 text-white"><?php echo e($t->type); ?></td>
                    <td class="px-4 py-3"><?php echo e($t->amount); ?></td>
                    <td class="px-4 py-3 text-meta-secondary"><?php echo e($t->created_at?->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3" class="px-4 py-6 text-center text-meta-secondary">No transactions.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="bg-meta-card rounded-[14px] border border-white/5 overflow-hidden">
        <h2 class="px-4 py-3 text-lg font-semibold text-white border-b border-white/5">Event Bookings</h2>
        <div class="max-h-64 overflow-y-auto">
            <?php $__empty_1 = true; $__currentLoopData = $eventBookings->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="px-4 py-3 border-t border-white/5 text-sm">
                    <span class="text-white"><?php echo e($b->event->title ?? '-'); ?></span>
                    <span class="text-meta-secondary"> · <?php echo e($b->event->date ?? ''); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="px-4 py-4 text-meta-secondary text-sm">None</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="bg-meta-card rounded-[14px] border border-white/5 overflow-hidden">
        <h2 class="px-4 py-3 text-lg font-semibold text-white border-b border-white/5">Livestream Bookings</h2>
        <div class="max-h-64 overflow-y-auto">
            <?php $__empty_1 = true; $__currentLoopData = $user->livestreamBookings->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="px-4 py-3 border-t border-white/5 text-sm">
                    <span class="text-white"><?php echo e($b->livestream->title ?? '-'); ?></span>
                    <span class="text-meta-secondary"> · <?php echo e($b->livestream->scheduled_at?->format('M d') ?? ''); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="px-4 py-4 text-meta-secondary text-sm">None</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/users/show.blade.php ENDPATH**/ ?>
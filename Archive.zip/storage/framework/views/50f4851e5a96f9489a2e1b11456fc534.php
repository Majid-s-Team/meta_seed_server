<?php $__env->startSection('title', 'Events'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6 animate-fade-in">
    <div>
        <h1 class="admin-page-title">Events</h1>
        <p class="admin-page-desc">Manage events and seats</p>
    </div>
    <a href="<?php echo e(route('admin.events.create')); ?>" class="admin-btn-primary">
        <i data-lucide="plus"></i>
        Add Event
    </a>
</div>

<?php if(session('success')): ?>
    <div class="mb-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm animate-fade-in"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="mb-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm animate-fade-in"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<form method="GET" class="flex flex-wrap gap-2 mb-5">
    <select name="status" class="admin-input w-auto min-w-[140px]">
        <option value="">All statuses</option>
        <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
        <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
        <option value="completed" <?php echo e(request('status') === 'completed' ? 'selected' : ''); ?>>Completed</option>
    </select>
    <select name="category_id" class="admin-input w-auto min-w-[160px]">
        <option value="">All categories</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="admin-btn-ghost">Filter</button>
</form>

<div class="admin-card overflow-hidden">
    <table class="admin-table w-full">
        <thead>
            <tr>
                <th>Title</th>
                <th>Category</th>
                <th>Date / Time</th>
                <th>Seats</th>
                <th>Coins</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="font-medium text-white"><?php echo e($event->title); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($event->category->name ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($event->date); ?> <?php echo e($event->time); ?></td>
                    <td><?php echo e($event->total_seats - $event->available_seats); ?> sold / <?php echo e($event->total_seats); ?></td>
                    <td><?php echo e($event->coins); ?></td>
                    <td>
                        <span class="inline-flex px-2.5 py-1 rounded-lg text-xs font-medium <?php echo e($event->status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : ($event->status === 'completed' ? 'bg-slate-500/20 text-slate-400' : 'bg-amber-500/20 text-amber-400')); ?>"><?php echo e($event->status); ?></span>
                    </td>
                    <td>
                        <div class="flex items-center gap-2">
                            <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="text-[var(--meta-accent-end)] hover:underline text-sm font-medium">Edit</a>
                            <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST" class="inline" onsubmit="return confirm('Delete this event?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-400 hover:underline text-sm">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        <?php echo $__env->make('admin.partials.empty', ['icon' => 'calendar-days', 'title' => 'No events yet', 'description' => 'Create your first event to start selling tickets.'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if($events->hasPages()): ?>
        <div class="px-5 py-4 border-t border-[var(--meta-border)]"><?php echo e($events->links('admin.partials.pagination')); ?></div>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/events/index.blade.php ENDPATH**/ ?>
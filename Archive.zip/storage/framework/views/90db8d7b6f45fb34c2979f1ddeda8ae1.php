<?php if($paginator->hasPages()): ?>
    <nav class="flex items-center justify-between gap-4 flex-wrap">
        <p class="text-[var(--meta-text-secondary)] text-sm">
            Showing <?php echo e($paginator->firstItem() ?? 0); ?>–<?php echo e($paginator->lastItem() ?? 0); ?> of <?php echo e($paginator->total()); ?>

        </p>
        <div class="flex gap-1.5">
            <?php if($paginator->onFirstPage()): ?>
                <span class="px-3 py-2 rounded-lg bg-white/5 text-[var(--meta-text-muted)] text-sm cursor-not-allowed">Prev</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-2 rounded-lg admin-btn-ghost text-sm transition">Prev</a>
            <?php endif; ?>
            <?php $__currentLoopData = $paginator->getUrlRange(max(1, $paginator->currentPage() - 2), min($paginator->lastPage(), $paginator->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <span class="px-3 py-2 rounded-lg text-sm font-medium text-white" style="background: linear-gradient(135deg, var(--meta-accent-start) 0%, var(--meta-accent-end) 100%);"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($url); ?>" class="px-3 py-2 rounded-lg admin-btn-ghost text-sm transition"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-2 rounded-lg admin-btn-ghost text-sm transition">Next</a>
            <?php else: ?>
                <span class="px-3 py-2 rounded-lg bg-white/5 text-[var(--meta-text-muted)] text-sm cursor-not-allowed">Next</span>
            <?php endif; ?>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/partials/pagination.blade.php ENDPATH**/ ?>
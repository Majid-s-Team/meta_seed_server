<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 animate-fade-in">
    <h1 class="admin-page-title">Transactions</h1>
    <p class="admin-page-desc">View-only transaction history</p>
</div>

<form method="GET" class="flex flex-wrap gap-2 mb-5">
    <select name="type" class="admin-input w-auto min-w-[120px]">
        <option value="">All types</option>
        <?php $__currentLoopData = \App\Models\Transaction::select('type')->distinct()->pluck('type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($t); ?>" <?php echo e(request('type') === $t ? 'selected' : ''); ?>><?php echo e($t); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="number" name="user_id" value="<?php echo e(request('user_id')); ?>" placeholder="User ID" class="admin-input w-28">
    <button type="submit" class="admin-btn-ghost">Filter</button>
</form>

<div class="admin-card overflow-hidden">
    <table class="admin-table w-full">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-[var(--meta-text-muted)]"><?php echo e($t->id); ?></td>
                    <td class="font-medium text-white"><?php echo e($t->user->name ?? '-'); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($t->type); ?></td>
                    <td><?php echo e($t->amount); ?></td>
                    <td class="text-[var(--meta-text-secondary)]"><?php echo e($t->created_at?->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">
                        <?php echo $__env->make('admin.partials.empty', ['icon' => 'wallet', 'title' => 'No transactions', 'description' => 'Transaction history will appear here.'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if($transactions->hasPages()): ?>
        <div class="px-5 py-4 border-t border-[var(--meta-border)]"><?php echo e($transactions->links('admin.partials.pagination')); ?></div>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/transactions/index.blade.php ENDPATH**/ ?>
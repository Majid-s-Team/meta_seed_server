<div class="admin-empty">
    <?php if(isset($icon)): ?>
        <i data-lucide="<?php echo e($icon); ?>" class="w-12 h-12"></i>
    <?php else: ?>
        <i data-lucide="inbox" class="w-12 h-12"></i>
    <?php endif; ?>
    <p class="admin-empty-title"><?php echo e($title ?? 'No data yet'); ?></p>
    <?php if(isset($description)): ?>
        <p class="admin-empty-desc"><?php echo e($description); ?></p>
    <?php endif; ?>
</div>
<script>if (typeof lucide !== 'undefined') lucide.createIcons();</script>
<?php /**PATH /Users/bukharee/Documents/Metaseat/meta_seed_server/resources/views/admin/partials/empty.blade.php ENDPATH**/ ?>